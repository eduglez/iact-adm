package memoria.modelo.culturacientifica;

import memoria.modelo.ActividadCientifica;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import proyectos.modelo.Organismo;

@Entity
public class ActividadFinanciada extends ActividadCientifica {
  
    private float cantidad;
    private String descripcion;

    @Temporal(javax.persistence.TemporalType.DATE)
    private Date fechaActividad;

    @ManyToOne
    private Organismo organismoFinanciador;

 
    public float getCantidad() {
        return cantidad;
    }

    public void setCantidad(float cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaActividad() {
        return fechaActividad;
    }

    public void setFechaActividad(Date fechaActividad) {
        this.fechaActividad = fechaActividad;
    }

    public Organismo getOrganismoFinanciador() {
        return organismoFinanciador;
    }

    public void setOrganismoFinanciador(Organismo organismoFinanciador) {
        this.organismoFinanciador = organismoFinanciador;
    }

   

    
}
