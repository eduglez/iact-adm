package memoria.modelo.culturacientifica;

import memoria.modelo.ActividadCientifica;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Temporal;

@Entity
public class Exposicion extends ActividadCientifica{
  
    private String titulo;

    @Temporal(javax.persistence.TemporalType.DATE)
    private Date fecha;


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

}
