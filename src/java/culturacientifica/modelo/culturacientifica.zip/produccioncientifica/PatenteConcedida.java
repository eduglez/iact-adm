package memoria.modelo.produccioncientifica;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Temporal;
import memoria.modelo.ActividadCientifica;

@Entity
public class PatenteConcedida extends ActividadCientifica {

    private String nombre;
    private String descripcion;
    private String referencia;

    @Temporal(javax.persistence.TemporalType.DATE)
    private Date fechaPublicacion;

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }
    
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    
    
}
