package memoria.modelo.produccioncientifica;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Temporal;
import memoria.modelo.ActividadCientifica;
import personal.modelo.Empleado;

@Entity
public class ArticuloNoSCI extends ActividadCientifica{

    private String titulo;
    private String editorial;
    private String otrosAutores;

    @Temporal(javax.persistence.TemporalType.DATE)
    private Date fechaPublicacion;
  
    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

   
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getOtrosAutores() {
        return otrosAutores;
    }

    public void setOtrosAutores(String otrosAutores) {
        this.otrosAutores = otrosAutores;
    }

    
    
}
