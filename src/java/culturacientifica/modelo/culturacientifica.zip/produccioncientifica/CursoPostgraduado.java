package memoria.modelo.produccioncientifica;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Temporal;
import memoria.modelo.ActividadCientifica;
import personal.modelo.Empleado;

@Entity
public class CursoPostgraduado extends ActividadCientifica {
 
    private String nombreCurso;
    private String nombreMaster;

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    public String getNombreMaster() {
        return nombreMaster;
    }

    public void setNombreMaster(String nombreMaster) {
        this.nombreMaster = nombreMaster;
    }
    
}
